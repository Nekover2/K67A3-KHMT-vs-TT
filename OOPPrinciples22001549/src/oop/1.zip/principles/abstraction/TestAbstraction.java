package oop.principles.abstraction;

public class TestAbstraction {

    public static void main(String[] args) {
        // Human human = new Human("John", 20); // cannot instantiate abstract class
        // human.printInfo();

        // Student is a Human, It inherits from Human
        Student student = new Student("John", 20, "123456");
        student.printInfo();
    }
}
