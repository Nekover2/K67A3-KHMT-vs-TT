package oop.principles.encapsulation;

public class TestStudent {
    public static void main(String[] args) {
        Student student = new Student("John", 20);
        student.printInfo();
        student.setAge(-1);
        student.printInfo();
    }
}
