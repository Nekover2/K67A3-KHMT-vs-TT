/**
* Just an exercise
*
* @author Nekov5
* @version 0.0.1 (pre-release)
* @since 2022-11-18
*/
public class bt7_22001549 {
    public static void main(String[] args) {
        System.out.println(10/3);
        //Khi sử dụng trực tiếp lệnh in ra phép tính (println), hàm sẽ mặc định tham số truyền vào là kiểu int, tiwf đó thực hiện tự động ép kiểu => in ra màn hình số 3, không phải 3.3333333333333...
    }
}