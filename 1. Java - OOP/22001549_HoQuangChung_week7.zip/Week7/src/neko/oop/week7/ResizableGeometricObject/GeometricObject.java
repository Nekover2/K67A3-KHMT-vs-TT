package neko.oop.week7.ResizableGeometricObject;

public interface GeometricObject {
    double getArea();

    double getPerimeter();
}
