package neko.oop.week7.ResizableGeometricObject;

public interface Resizable {
    void resize(int percent);
}
