package neko.oop.week7.GeometricObject;

public interface GeometricObject {
    double getArea();

    double getPerimeter();
}
