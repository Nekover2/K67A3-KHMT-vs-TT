import neko.oop.week6.animal.*;

public class Main {
    public static void main(String[] args) {
        
    }
}